# Congestion Tax Calculator

Welcome to the Persici Financial Technologies assessment.

This repository contains a developer [assignment](ASSIGNMENT.md) used as a basis for candidate intervew and evaluation.

Clone this repository to get started. Due to a number of reasons, not least privacy, you will be asked to zip your solution and share it in, instead of submitting a pull-request.
