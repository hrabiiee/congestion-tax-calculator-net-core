﻿using congestion.calculator.Vehicles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace congestion.calculator
{
    internal class TollCalculator
    {

        internal static bool IsTollFreeVehicle(ITollVehicle vehicleToll)
        {
            if (vehicleToll == null) return false;

            return vehicleToll.IsTollFreeVehicle();
        }

        internal static int GetTollFee(DateTime date, ITollVehicle vehicle)
        {
            if (IsTollFreeDate(date) || IsTollFreeVehicle(vehicle)) return 0;

            List<DateFeeSetting> fees = Configuration.ReadFeeFromSettingFile();

            var result = fees.Where(p => p.FromDate >= date && p.ToDate <= date).FirstOrDefault();

            if (result != null)
                return result.Amount;

            return 0;

        }

        private static Boolean IsTollFreeDate(DateTime date)
        {

            var freeDates = Configuration.ReadFreeDateFromSettingFile();

            int year = date.Year;
            int month = date.Month;
            int day = date.Day;

            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday) return true;

            if (year == freeDates.Year)
            {
                return freeDates.DayAndIsFree.Where(p => p.DayOfYear == day).First().IsFree;

            }
            return false;

        }
    }
}
