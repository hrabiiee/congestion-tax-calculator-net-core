﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator
{
    internal static class Configuration
    {
        internal static List<DateFeeSetting> ReadFeeFromSettingFile() {
            return new Setting().DateFees;
        }

        internal static DayOfYearsSetting ReadFreeDateFromSettingFile() {
            return new Setting().FreeDates;
        }
    }
}
