using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace congestion.calculator.Vehicles
{
    public class Tractor : IVehicle, ITollVehicle
    {
        public string GetVehicleType()
        {
            return "Tractor";
        }

        public bool IsTollFreeVehicle()
        {
            return true;
        }
    }
}