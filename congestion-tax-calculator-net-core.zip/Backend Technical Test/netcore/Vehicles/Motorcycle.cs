﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator.Vehicles
{
    internal class Motorcycle : IVehicle, ITollVehicle
    {
        public string GetVehicleType()
        {
            throw new NotImplementedException();
        }

        public bool IsTollFreeVehicle()
        {
            return true;
        }
    }
}
