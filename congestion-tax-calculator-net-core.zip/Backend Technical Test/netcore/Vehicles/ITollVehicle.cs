﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator.Vehicles
{
    internal interface ITollVehicle
    {
        bool IsTollFreeVehicle();
    }
}
