﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator
{
     internal class Setting {
        internal List<DateFeeSetting> DateFees { get; set; }
        internal DayOfYearsSetting FreeDates { get; set; }
    }

    internal class DateFeeSetting
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public int Amount { get; set; }

    }

    internal class DayOfYearsSetting
    {
        public  int Year { get; set; }
        public List<DayAndIsFree> DayAndIsFree { get; set; } 
        
    }


    internal class DayAndIsFree
    {
        internal int DayOfYear { get; set; }
        internal bool IsFree { get; set; }   

    }
}
